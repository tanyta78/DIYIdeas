import { Injectable } from "@angular/core";
import * as firebase from 'firebase';
import { Router } from '@angular/router';


@Injectable()
export class AuthService {
	token: string;
	//isAdmin: boolean = false;
	isAdmin: boolean = true;

	uid: string;

	constructor(
		private router: Router,
		
	) { }

	signupUser(email: string, password: string) {
		firebase.auth().createUserWithEmailAndPassword(email, password)
			.then(data => {
				console.log(data);
				//TODO: save new created user in users db collection
				
				this.router.navigate(['/signin']);
			})
			.catch(
				error => console.log(error)
			);
	}

	signupUserIn(email: string, password: string) {
		return firebase.auth().createUserWithEmailAndPassword(email, password);
			
	}

	signinUser(email: string, password: string) {
		firebase.auth().signInWithEmailAndPassword(email, password)
			.then(res => {
				console.log(res)
				this.uid = res.user.uid;
			
				this.router.navigate([`/admin/profile/${this.uid}/edit`]);
			
				console.log(res.user);
				firebase.auth().currentUser.getIdToken()
					.then(
						(token: string) => this.token = token
					)
			})
			.catch(
				error => console.log(error)
			);
	}

	logout() {
		firebase.auth().signOut();
		this.token = null;
		this.router.navigate(['/']);
	}

	getToken() {
		firebase.auth().currentUser.getIdToken()
			.then(
				(token: string) => {
					this.token = token
				});
		return this.token;
	}

	isAuthenticated() {
		return this.token != null;
	}

}