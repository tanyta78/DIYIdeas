import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-start',
  templateUrl: './project-start.component.html',
  styleUrls: ['./project-start.component.css']
})
export class ProjectStartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
