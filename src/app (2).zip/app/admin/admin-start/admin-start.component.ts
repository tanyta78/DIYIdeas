import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-start',
  templateUrl: './admin-start.component.html',
  styleUrls: ['./admin-start.component.css']
})
export class AdminStartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
