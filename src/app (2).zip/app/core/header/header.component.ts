import { Component } from '@angular/core';
import { Response } from '@angular/http';

import { DataStorageService } from '../../shared/data-storage.service';
import { AuthService } from '../../auth/auth.service';
import { UserService } from '../../admin/user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {

  constructor(
    private dataStorageService: DataStorageService,
    private authService: AuthService,
    private userService: UserService) { }

  onSaveData() {
    this.dataStorageService.storeProjects()
      .subscribe(
        (res: Response) => {
          console.log(res);
        }
      );
  }

  onFetchData() {
    this.dataStorageService.getProjects();
  }

  onLogout() {
    this.authService.logout();
  }

  isAuthenticated() {
    return this.authService.isAuthenticated();
  }

  isAdmin() {
    // return true;
    if (!this.authService.isAuthenticated()) {
      return false
    } else {
      let userId = this.userService.userUid;
      this.userService.getById(userId).subscribe(
        (data) => {
          return data.json().role === 'admin' ? true : false;

        })
    }
  }
}
